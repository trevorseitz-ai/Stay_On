"use client";

import { FormEvent, useEffect, useRef, useState } from "react";

type GameState = "ready" | "countdown" | "playing" | "crashed";

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [feedbackReason, setFeedbackReason] = useState("fun");
  const [feedbackNote, setFeedbackNote] = useState("");
  const [lastDistance, setLastDistance] = useState(0);

  const visitorId = () => {
    const existing = localStorage.getItem("stay-on-visitor");
    if (existing) return existing;
    const id = crypto.randomUUID();
    localStorage.setItem("stay-on-visitor", id);
    return id;
  };

  const sendFeedback = async (event: FormEvent) => {
    event.preventDefault();
    await fetch("/api/testing", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        kind: "feedback",
        visitorId: visitorId(),
        reason: feedbackReason,
        note: feedbackNote,
        distanceMetres: lastDistance,
      }),
    });
    setFeedbackSent(true);
    setFeedbackOpen(false);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let dpr = 1;
    let state: GameState = "ready";
    let pressed = false;
    let distance = 0;
    let playerX = 0;
    let steerVelocity = 0;
    let speed = 155;
    let countdownLeft = 3;
    let countdownEndsAt = 0;
    let goFlash = 0;
    let difficultyLevel = 0;
    let levelFlash = 0;
    let levelMessage = "";
    let lastTime = performance.now();
    let shake = 0;
    let best = Number(localStorage.getItem("stay-on-best") || 0);
    let runNumber = Number(localStorage.getItem("stay-on-runs") || 0);
    const anonymousId = visitorId();

    const track = (eventName: string, metres = 0) => {
      void fetch("/api/testing", {
        method: "POST",
        headers: { "content-type": "application/json" },
        keepalive: true,
        body: JSON.stringify({
          kind: "event",
          visitorId: anonymousId,
          eventName,
          runNumber,
          distanceMetres: metres,
        }),
      });
    };

    const baseRoadWidth = () => Math.max(155, Math.min(235, width * 0.56));
    const speedSteps = () =>
      difficultyLevel === 1 ? 1 : difficultyLevel >= 3 ? difficultyLevel - 2 : 0;
    const narrowSteps = () =>
      difficultyLevel === 2 ? 1 : difficultyLevel >= 3 ? difficultyLevel - 2 : 0;
    const roadWidth = () => Math.max(118, baseRoadWidth() - narrowSteps() * 14);
    const carY = () => height * 0.57;
    const steerStrength = () => distance < 150 ? 68 : distance < 400 ? 105 : 145;

    const hash = (n: number) => {
      const x = Math.sin(n * 91.127 + 42.51) * 43758.5453;
      return (x - Math.floor(x)) * 2 - 1;
    };

    const roadCenter = (worldY: number) => {
      const spacing = 310;
      const knot = Math.floor(worldY / spacing);
      const t = (worldY - knot * spacing) / spacing;
      const smooth = t * t * (3 - 2 * t);
      const margin = baseRoadWidth() * 0.62;
      const amplitude = Math.max(28, width / 2 - margin);
      const a = hash(knot) * amplitude;
      const b = hash(knot + 1) * amplitude;
      return width / 2 + a + (b - a) * smooth;
    };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (state === "ready") playerX = roadCenter(0);
    };

    const begin = () => {
      setShowFeedback(false);
      setFeedbackOpen(false);
      setFeedbackSent(false);
      runNumber += 1;
      localStorage.setItem("stay-on-runs", String(runNumber));
      track("run_started");
      state = "countdown";
      countdownLeft = 3;
      countdownEndsAt = performance.now() + 3000;
      goFlash = 0;
      difficultyLevel = 0;
      levelFlash = 0;
      levelMessage = "";
      distance = 0;
      speed = 155;
      steerVelocity = 0;
      playerX = roadCenter(0);
      shake = 0;
    };

    const actionDown = (event: PointerEvent) => {
      event.preventDefault();
      canvas.setPointerCapture?.(event.pointerId);
      if (state === "ready" || state === "crashed") begin();
      pressed = true;
      if (state === "playing" && steerVelocity >= 0) {
        steerVelocity = -steerStrength() * 0.72;
      }
    };
    const actionUp = (event: PointerEvent) => {
      event.preventDefault();
      pressed = false;
      if (state === "playing" && steerVelocity <= 0) {
        steerVelocity = steerStrength() * 0.72;
      }
    };

    const drawRoad = () => {
      const step = 8;
      ctx.beginPath();
      for (let y = -step; y <= height + step; y += step) {
        const world = distance + (carY() - y);
        const x = roadCenter(world) - roadWidth() / 2;
        if (y === -step) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      for (let y = height + step; y >= -step; y -= step) {
        const world = distance + (carY() - y);
        ctx.lineTo(roadCenter(world) + roadWidth() / 2, y);
      }
      ctx.closePath();
      const roadGradient = ctx.createLinearGradient(0, 0, 0, height);
      roadGradient.addColorStop(0, "#151a1f");
      roadGradient.addColorStop(1, "#232a2f");
      ctx.fillStyle = roadGradient;
      ctx.fill();

      ctx.lineWidth = 3;
      ctx.strokeStyle = "#d7ff3f";
      ctx.shadowBlur = 10;
      ctx.shadowColor = "#baff29";
      for (const side of [-1, 1]) {
        ctx.beginPath();
        for (let y = -step; y <= height + step; y += step) {
          const world = distance + (carY() - y);
          const x = roadCenter(world) + side * roadWidth() / 2;
          if (y === -step) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      ctx.shadowBlur = 0;

      ctx.setLineDash([22, 26]);
      ctx.lineDashOffset = distance % 48;
      ctx.lineWidth = 2;
      ctx.strokeStyle = "rgba(255,255,255,.18)";
      ctx.beginPath();
      for (let y = -step; y <= height + step; y += step) {
        const world = distance + (carY() - y);
        const x = roadCenter(world);
        if (y === -step) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    };

    const drawCar = () => {
      const x = playerX;
      const y = carY();
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(Math.max(-0.13, Math.min(0.13, steerVelocity / 750)));
      ctx.shadowBlur = state === "crashed" ? 22 : 12;
      ctx.shadowColor = state === "crashed" ? "#ffb000" : "#ff3b30";
      ctx.fillStyle = "#ff3b30";
      ctx.beginPath();
      ctx.roundRect(-17, -30, 34, 60, 9);
      ctx.fill();
      ctx.fillStyle = "#111a24";
      ctx.fillRect(-12, -15, 24, 17);
      ctx.fillStyle = "#ffe66d";
      ctx.fillRect(-13, -27, 7, 4);
      ctx.fillRect(6, -27, 7, 4);
      ctx.restore();
    };

    const roadsideAds = [
      { top: "NITRO", bottom: "COLA", color: "#ff4d3d" },
      { top: "TURBO", bottom: "TIRES", color: "#4bd7ff" },
      { top: "MILE 8", bottom: "DINER", color: "#ffd447" },
      { top: "PIXEL", bottom: "FUEL", color: "#d47cff" },
    ];

    const drawRoadsideAds = () => {
      const spacing = 360;
      const visibleMin = distance - (height - carY()) - spacing;
      const visibleMax = distance + carY() + spacing;
      const first = Math.floor(visibleMin / spacing);
      const last = Math.ceil(visibleMax / spacing);

      for (let index = first; index <= last; index += 1) {
        const world = index * spacing + 170;
        const y = carY() - (world - distance);
        if (y < 112 || y > height + 50) continue;
        const ad = roadsideAds[Math.abs(index) % roadsideAds.length];
        const scale = Math.max(0.58, Math.min(1.08, 0.54 + y / height * 0.58));
        const boardW = 88 * scale;
        const boardH = 40 * scale;
        const side = index % 2 === 0 ? -1 : 1;
        const rawX = roadCenter(world) + side * (roadWidth() / 2 + 13 + boardW / 2);
        const x = Math.max(boardW / 2 + 5, Math.min(width - boardW / 2 - 5, rawX));

        ctx.save();
        ctx.strokeStyle = "rgba(225,235,236,.56)";
        ctx.lineWidth = Math.max(1, 2 * scale);
        ctx.beginPath();
        ctx.moveTo(x, y + boardH / 2);
        ctx.lineTo(x, y + boardH / 2 + 22 * scale);
        ctx.stroke();
        ctx.fillStyle = "#070b0e";
        ctx.strokeStyle = ad.color;
        ctx.shadowBlur = 9 * scale;
        ctx.shadowColor = ad.color;
        ctx.fillRect(x - boardW / 2, y - boardH / 2, boardW, boardH);
        ctx.strokeRect(x - boardW / 2, y - boardH / 2, boardW, boardH);
        ctx.shadowBlur = 0;
        ctx.fillStyle = ad.color;
        ctx.textAlign = "center";
        ctx.font = `900 ${Math.max(8, 11 * scale)}px Arial, sans-serif`;
        ctx.fillText(ad.top, x, y - 2 * scale);
        ctx.fillStyle = "rgba(245,250,250,.88)";
        ctx.font = `700 ${Math.max(6, 8 * scale)}px ui-monospace, monospace`;
        ctx.fillText(ad.bottom, x, y + 11 * scale);
        ctx.restore();
      }
    };

    const drawSteeringControl = () => {
      const x = width / 2;
      const y = height * 0.84;
      const radius = Math.min(43, width * 0.105);
      ctx.save();
      ctx.globalAlpha = state === "playing" ? 0.56 : 0.9;
      ctx.strokeStyle = pressed ? "#d7ff3f" : "rgba(235,245,246,.72)";
      ctx.fillStyle = "rgba(4,8,10,.62)";
      ctx.lineWidth = 5;
      ctx.shadowBlur = pressed ? 18 : 8;
      ctx.shadowColor = pressed ? "#d7ff3f" : "rgba(220,240,240,.35)";
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(x, y, radius * 0.22, 0, Math.PI * 2);
      ctx.moveTo(x, y - radius * 0.22);
      ctx.lineTo(x, y - radius * 0.94);
      ctx.moveTo(x - radius * 0.19, y + radius * 0.12);
      ctx.lineTo(x - radius * 0.78, y + radius * 0.56);
      ctx.moveTo(x + radius * 0.19, y + radius * 0.12);
      ctx.lineTo(x + radius * 0.78, y + radius * 0.56);
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.fillStyle = "rgba(240,248,249,.78)";
      ctx.textAlign = "center";
      ctx.font = "700 10px ui-monospace, monospace";
      ctx.fillText("PLACE THUMB HERE", x, y + radius + 21);
      ctx.restore();
    };

    const drawBannerAd = () => {
      const boardW = width - 8;
      const x = width / 2 - boardW / 2;
      ctx.fillStyle = "rgba(5,8,10,.97)";
      ctx.strokeStyle = "rgba(235,245,246,.42)";
      ctx.lineWidth = 2;
      ctx.fillRect(x, 5, boardW, 56);
      ctx.strokeRect(x, 5, boardW, 56);
      ctx.fillStyle = "rgba(235,245,246,.38)";
      ctx.textAlign = "left";
      ctx.font = "600 7px ui-monospace, monospace";
      ctx.fillText("ADVERTISEMENT", x + 6, 15);
      ctx.fillStyle = "rgba(235,245,246,.72)";
      ctx.textAlign = "center";
      ctx.font = "700 12px ui-monospace, monospace";
      ctx.fillText("YOUR AD HERE", width / 2, 39);
    };

    const drawHud = () => {
      ctx.textAlign = "left";
      ctx.fillStyle = "rgba(233,244,246,.58)";
      ctx.font = "600 11px ui-monospace, monospace";
      ctx.fillText("DISTANCE", 18, 78);
      ctx.fillStyle = "#f2fbfc";
      ctx.font = "700 24px ui-monospace, monospace";
      ctx.fillText(`${Math.floor(distance / 10).toString().padStart(4, "0")} m`, 18, 101);
      ctx.textAlign = "right";
      ctx.fillStyle = "rgba(233,244,246,.58)";
      ctx.font = "600 11px ui-monospace, monospace";
      ctx.fillText("BEST", width - 18, 78);
      ctx.fillStyle = "#f2fbfc";
      ctx.font = "700 18px ui-monospace, monospace";
      ctx.fillText(`${Math.floor(best / 10)} m`, width - 18, 100);
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(215,255,63,.72)";
      ctx.font = "700 10px ui-monospace, monospace";
      ctx.fillText(`LEVEL ${difficultyLevel + 1}`, width / 2, 91);
    };

    const drawCountdown = () => {
      const number = Math.max(1, Math.ceil(countdownLeft));
      ctx.save();
      ctx.textAlign = "center";
      ctx.fillStyle = "#d7ff3f";
      ctx.shadowBlur = 28;
      ctx.shadowColor = "#baff29";
      ctx.font = `900 ${Math.min(112, width * 0.28)}px Arial, sans-serif`;
      ctx.fillText(String(number), width / 2, height * 0.37);
      ctx.shadowBlur = 0;
      ctx.fillStyle = "rgba(244,251,252,.72)";
      ctx.font = "700 12px ui-monospace, monospace";
      ctx.fillText("GET YOUR THUMB READY", width / 2, height * 0.37 + 34);
      ctx.restore();
    };

    const overlay = (title: string, subtitle: string) => {
      ctx.fillStyle = "rgba(3,6,8,.70)";
      ctx.fillRect(0, 0, width, height);
      ctx.textAlign = "center";
      ctx.fillStyle = "#f4fbfc";
      ctx.font = `900 ${Math.min(54, width * 0.14)}px Arial, sans-serif`;
      ctx.fillText(title, width / 2, height * 0.4);
      ctx.fillStyle = "#d7ff3f";
      ctx.font = "700 15px ui-monospace, monospace";
      ctx.fillText(subtitle, width / 2, height * 0.4 + 37);
      ctx.fillStyle = "rgba(244,251,252,.58)";
      ctx.font = "600 12px ui-monospace, monospace";
      ctx.fillText("HOLD = LEFT  •  RELEASE = RIGHT", width / 2, height * 0.4 + 72);
    };

    const frame = (now: number) => {
      const dt = Math.min((now - lastTime) / 1000, 0.035);
      lastTime = now;
      if (state === "countdown") {
        countdownLeft = Math.max(0, (countdownEndsAt - now) / 1000);
        if (countdownLeft <= 0) {
          state = "playing";
          goFlash = 0.55;
        }
      }
      if (state === "playing") {
        const nextLevel = Math.floor(distance / 5000);
        if (nextLevel > difficultyLevel) {
          difficultyLevel = nextLevel;
          levelMessage =
            nextLevel === 1
              ? "FASTER"
              : nextLevel === 2
                ? "ROAD NARROWER"
                : "FASTER  •  NARROWER";
          levelFlash = 1.35;
        }
        speed = Math.min(400, 155 + distance * 0.025 + speedSteps() * 15);
        distance += speed * dt;
        const target = pressed ? -steerStrength() : steerStrength();
        steerVelocity += (target - steerVelocity) * Math.min(1, dt * 12);
        playerX += steerVelocity * dt;
        const safe = roadWidth() / 2 - 17;
        if (Math.abs(playerX - roadCenter(distance)) > safe) {
          state = "crashed";
          shake = 11;
          const metres = Math.floor(distance / 10);
          setLastDistance(metres);
          setShowFeedback(true);
          track("run_ended", metres);
          if (distance > best) {
            best = distance;
            localStorage.setItem("stay-on-best", String(best));
          }
        }
        if (goFlash > 0) goFlash -= dt;
        if (levelFlash > 0) levelFlash -= dt;
      }

      ctx.save();
      if (shake > 0) {
        ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
        shake *= 0.91;
      }
      ctx.fillStyle = "#060a0c";
      ctx.fillRect(-20, -20, width + 40, height + 40);
      drawRoad();
      drawRoadsideAds();
      drawCar();
      drawHud();
      if (state === "ready") overlay("STAY ON", "TAP TO DRIVE");
      if (state === "countdown") drawCountdown();
      if (state === "crashed") overlay("CRASHED", "TAP FOR ONE MORE RUN");
      if (goFlash > 0) {
        ctx.textAlign = "center";
        ctx.fillStyle = "#d7ff3f";
        ctx.font = `900 ${Math.min(72, width * 0.18)}px Arial, sans-serif`;
        ctx.fillText("GO!", width / 2, height * 0.35);
      }
      if (levelFlash > 0) {
        ctx.textAlign = "center";
        ctx.fillStyle = "#ffdb45";
        ctx.shadowBlur = 22;
        ctx.shadowColor = "#ff9f1c";
        ctx.font = `900 ${Math.min(46, width * 0.12)}px Arial, sans-serif`;
        ctx.fillText(`LEVEL ${difficultyLevel + 1}`, width / 2, height * 0.32);
        ctx.shadowBlur = 0;
        ctx.fillStyle = "rgba(245,250,250,.82)";
        ctx.font = "700 11px ui-monospace, monospace";
        ctx.fillText(levelMessage, width / 2, height * 0.32 + 25);
      }
      drawBannerAd();
      drawSteeringControl();
      ctx.restore();
      requestAnimationFrame(frame);
    };

    window.addEventListener("resize", resize);
    canvas.addEventListener("pointerdown", actionDown, { passive: false });
    canvas.addEventListener("pointerup", actionUp, { passive: false });
    canvas.addEventListener("pointercancel", actionUp, { passive: false });
    resize();
    track("game_opened");
    const animation = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(animation);
      window.removeEventListener("resize", resize);
      canvas.removeEventListener("pointerdown", actionDown);
      canvas.removeEventListener("pointerup", actionUp);
      canvas.removeEventListener("pointercancel", actionUp);
    };
  }, []);

  return (
    <main className="game-shell">
      <canvas ref={canvasRef} aria-label="Stay On driving game" />
      {showFeedback && !feedbackOpen && (
        <button className="feedback-trigger" onClick={() => setFeedbackOpen(true)}>
          {feedbackSent ? "THANKS!" : "QUICK FEEDBACK"}
        </button>
      )}
      {feedbackOpen && (
        <div className="feedback-backdrop" role="dialog" aria-modal="true" aria-label="Game feedback">
          <form className="feedback-card" onSubmit={sendFeedback}>
            <button
              type="button"
              className="feedback-close"
              aria-label="Close feedback"
              onClick={() => setFeedbackOpen(false)}
            >
              ×
            </button>
            <p className="feedback-kicker">YOU MADE IT {lastDistance} m</p>
            <h2>What made you stop?</h2>
            <div className="feedback-options">
              {[
                ["fun", "Nothing—I’d keep playing"],
                ["hard", "It got too hard"],
                ["controls", "The controls felt off"],
                ["easy", "It was too easy"],
                ["other", "Something else"],
              ].map(([value, label]) => (
                <label key={value} className={feedbackReason === value ? "selected" : ""}>
                  <input
                    type="radio"
                    name="reason"
                    value={value}
                    checked={feedbackReason === value}
                    onChange={() => setFeedbackReason(value)}
                  />
                  {label}
                </label>
              ))}
            </div>
            <textarea
              value={feedbackNote}
              onChange={(event) => setFeedbackNote(event.target.value)}
              placeholder="Anything else? (optional)"
              maxLength={600}
            />
            <button className="feedback-submit" type="submit">SEND FEEDBACK</button>
            <p className="feedback-privacy">Anonymous—no name or email collected.</p>
          </form>
        </div>
      )}
    </main>
  );
}
